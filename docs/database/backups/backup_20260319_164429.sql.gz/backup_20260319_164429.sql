-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: apu_system
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apu`
--

DROP TABLE IF EXISTS `apu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `proyecto_id` int DEFAULT NULL,
  `unidad` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `codigo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `rendimiento` decimal(10,2) DEFAULT NULL,
  `costo_unitario` decimal(15,2) DEFAULT NULL,
  `costo_total` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_proyecto` (`proyecto_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `FK_B90484409033212A` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu`
--

LOCK TABLES `apu` WRITE;
/*!40000 ALTER TABLE `apu` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apu_equipment`
--

DROP TABLE IF EXISTS `apu_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu_equipment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `numero` int NOT NULL,
  `tarifa` decimal(10,2) NOT NULL,
  `c_hora` decimal(10,4) NOT NULL,
  `created_at` datetime NOT NULL,
  `apu_item_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A0026F4B5A5975C` (`apu_item_id`),
  CONSTRAINT `FK_A0026F4B5A5975C` FOREIGN KEY (`apu_item_id`) REFERENCES `apu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu_equipment`
--

LOCK TABLES `apu_equipment` WRITE;
/*!40000 ALTER TABLE `apu_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apu_items`
--

DROP TABLE IF EXISTS `apu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `description` varchar(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `khu` decimal(10,4) NOT NULL,
  `rendimiento_uh` decimal(10,4) NOT NULL,
  `total_cost` decimal(15,2) DEFAULT NULL,
  `equipment_cost` decimal(15,2) DEFAULT NULL,
  `labor_cost` decimal(15,2) DEFAULT NULL,
  `material_cost` decimal(15,2) DEFAULT NULL,
  `transport_cost` decimal(15,2) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_65F54B27D17F50A6` (`uuid`),
  KEY `IDX_65F54B279033212A` (`tenant_id`),
  CONSTRAINT `FK_65F54B279033212A` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu_items`
--

LOCK TABLES `apu_items` WRITE;
/*!40000 ALTER TABLE `apu_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apu_labor`
--

DROP TABLE IF EXISTS `apu_labor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu_labor` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `numero` int NOT NULL,
  `jor_hora` decimal(10,4) NOT NULL,
  `c_hora` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `apu_item_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8AAC276BB5A5975C` (`apu_item_id`),
  CONSTRAINT `FK_8AAC276BB5A5975C` FOREIGN KEY (`apu_item_id`) REFERENCES `apu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu_labor`
--

LOCK TABLES `apu_labor` WRITE;
/*!40000 ALTER TABLE `apu_labor` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu_labor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apu_materials`
--

DROP TABLE IF EXISTS `apu_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu_materials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `unidad` varchar(50) NOT NULL,
  `cantidad` decimal(15,4) NOT NULL,
  `precio_unitario` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `apu_item_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_422FE5C2B5A5975C` (`apu_item_id`),
  CONSTRAINT `FK_422FE5C2B5A5975C` FOREIGN KEY (`apu_item_id`) REFERENCES `apu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu_materials`
--

LOCK TABLES `apu_materials` WRITE;
/*!40000 ALTER TABLE `apu_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apu_transport`
--

DROP TABLE IF EXISTS `apu_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apu_transport` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `unidad` varchar(50) NOT NULL,
  `cantidad` decimal(15,4) NOT NULL,
  `dmt` decimal(10,2) NOT NULL,
  `tarifa_km` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `apu_item_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BF93D259B5A5975C` (`apu_item_id`),
  CONSTRAINT `FK_BF93D259B5A5975C` FOREIGN KEY (`apu_item_id`) REFERENCES `apu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apu_transport`
--

LOCK TABLES `apu_transport` WRITE;
/*!40000 ALTER TABLE `apu_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `apu_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_ips` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_score` int DEFAULT '0' COMMENT '0-100',
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blocked_until` timestamp NULL DEFAULT NULL COMMENT 'NULL = bloqueo permanente',
  `blocked_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'manual, automatic, threat_intel',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_blocked_until` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20250108000000','2026-03-17 10:56:38',NULL),('DoctrineMigrations\\Version20260108000001','2026-03-17 11:30:33',95),('DoctrineMigrations\\Version20260317170000','2026-03-17 11:45:04',16),('DoctrineMigrations\\Version20260319000000','2026-03-19 13:33:17',28),('DoctrineMigrations\\Version20260319000001','2026-03-19 13:48:02',32),('DoctrineMigrations\\Version20260319210000','2026-03-19 15:57:50',28),('DoctrineMigrations\\Version20260319220000','2026-03-19 16:21:12',28),('DoctrineMigrations\\Version20260319230000','2026-03-19 16:42:27',20);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_sessions`
--

DROP TABLE IF EXISTS `login_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fingerprint` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_user_active` (`user_id`,`is_active`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `login_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_sessions`
--

LOCK TABLES `login_sessions` WRITE;
/*!40000 ALTER TABLE `login_sessions` DISABLE KEYS */;
INSERT INTO `login_sessions` VALUES (1,1,'b5km6146bbu5ibl6k778lj6e92','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-16 21:31:33','2026-03-16 22:31:33',1,'2026-03-16 21:31:33'),(2,1,'8aev40j8eiqfof3979g2aaimco','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-16 21:46:33','2026-03-16 22:46:33',1,'2026-03-16 21:46:33'),(3,1,'apc5p3bjje5mdoj2fa13tca148','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-17 17:24:09','2026-03-17 18:24:09',1,'2026-03-17 17:24:09'),(5,1,'vvhblm06as2qc2rvm1ltbmunlb','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-19 17:26:43','2026-03-19 18:26:43',1,'2026-03-19 17:26:43'),(6,1,'lkp0t1nvmg6gi37trgrbnoldji','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-19 20:41:02','2026-03-19 21:41:02',1,'2026-03-19 20:41:02'),(8,1,'0k1d76hsa0h965pn9qnb8qhbv9','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','7a148d80bc4a0e790925282d2195c4dd5d9ea7330221dc851dc1353adc9a52e0','2026-03-19 20:49:46','2026-03-19 21:49:46',1,'2026-03-19 20:49:46');
/*!40000 ALTER TABLE `login_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES (1,3,'c1bfe8df560a0c8b52e9242c8cd7bfc0b136a8d93074d289db59ef924a0439d8','2026-03-19 19:09:40',0,'2026-03-19 18:09:40');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyectos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `client_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('draft','active','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `total_budget` decimal(20,2) DEFAULT '0.00',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT 'COP',
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_code_per_tenant` (`tenant_id`,`code`),
  KEY `idx_tenant_status` (`tenant_id`,`status`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `proyectos_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `proyectos_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos`
--

LOCK TABLES `proyectos` WRITE;
/*!40000 ALTER TABLE `proyectos` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limit_logs`
--

DROP TABLE IF EXISTS `rate_limit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IP o identificador del cliente',
  `endpoint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Ruta del endpoint (ej: /login)',
  `attempts` int DEFAULT '1' COMMENT 'Número de intentos',
  `window_start` datetime NOT NULL COMMENT 'Inicio de la ventana de tiempo',
  `window_end` datetime NOT NULL COMMENT 'Fin de la ventana de tiempo',
  `exceeded_at` datetime DEFAULT NULL COMMENT 'Momento en que se excedió el límite',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identifier_endpoint` (`identifier`,`endpoint`),
  KEY `idx_window` (`window_end`),
  KEY `idx_cleanup` (`window_end`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limit_logs`
--

LOCK TABLES `rate_limit_logs` WRITE;
/*!40000 ALTER TABLE `rate_limit_logs` DISABLE KEYS */;
INSERT INTO `rate_limit_logs` VALUES (1,'172.19.0.1','login',1,'2026-03-19 16:43:32','2026-03-19 16:58:32',NULL,'2026-03-19 16:43:32');
/*!40000 ALTER TABLE `rate_limit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recovery_codes`
--

DROP TABLE IF EXISTS `recovery_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recovery_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Hash del código de recuperación',
  `used_at` datetime DEFAULT NULL COMMENT 'Fecha cuando fue usado',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_unused` (`user_id`,`used_at`),
  CONSTRAINT `fk_recovery_codes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recovery_codes`
--

LOCK TABLES `recovery_codes` WRITE;
/*!40000 ALTER TABLE `recovery_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revit_files`
--

DROP TABLE IF EXISTS `revit_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revit_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `uploaded_by_id` bigint unsigned NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int unsigned NOT NULL,
  `file_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `processing_result` json DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `uploaded_at` datetime NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_93F26D7B9033212A` (`tenant_id`),
  KEY `IDX_93F26D7BA2B28FE8` (`uploaded_by_id`),
  KEY `IDX_93F26D7B_STATUS` (`status`),
  KEY `IDX_93F26D7B_TYPE` (`file_type`),
  CONSTRAINT `FK_93F26D7B9033212A` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_93F26D7BA2B28FE8` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revit_files`
--

LOCK TABLES `revit_files` WRITE;
/*!40000 ALTER TABLE `revit_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `revit_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_events`
--

DROP TABLE IF EXISTS `security_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` enum('INFO','WARNING','CRITICAL') COLLATE utf8mb4_unicode_ci DEFAULT 'INFO',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `event_data` json DEFAULT NULL COMMENT 'Datos adicionales del evento',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `security_events_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `security_events_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_events`
--

LOCK TABLES `security_events` WRITE;
/*!40000 ALTER TABLE `security_events` DISABLE KEYS */;
INSERT INTO `security_events` VALUES (1,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-16 21:31:33'),(2,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-16 21:46:33'),(3,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-17 17:24:09'),(4,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-19 17:26:43'),(5,2,3,'password_reset_requested','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"email\": \"user@abc.com\"}','2026-03-19 18:09:40'),(6,1,1,'2fa_failed','WARNING','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp\", \"reason\": \"Invalid verification code\"}','2026-03-19 18:11:35'),(7,1,1,'2fa_failed','WARNING','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp\", \"reason\": \"Invalid verification code\"}','2026-03-19 18:12:47'),(8,1,1,'2fa_failed','WARNING','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp\", \"reason\": \"Invalid verification code\"}','2026-03-19 18:24:54'),(9,1,1,'2fa_failed','WARNING','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp\", \"reason\": \"Invalid verification code\"}','2026-03-19 18:25:59'),(10,1,1,'2fa_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp_enabled\"}','2026-03-19 18:29:28'),(11,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-19 20:41:02'),(12,1,1,'login_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',NULL,'2026-03-19 20:49:46'),(13,1,1,'2fa_success','INFO','172.19.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','{\"method\": \"totp\"}','2026-03-19 20:53:11');
/*!40000 ALTER TABLE `security_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'UUID Ãºnico del tenant',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nombre de la empresa',
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Identificador URL-friendly',
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Dominio personalizado (opcional)',
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT 'COP',
  `is_active` tinyint(1) DEFAULT '1',
  `plan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'basic' COMMENT 'basic, professional, enterprise',
  `max_users` int DEFAULT '5',
  `max_projects` int DEFAULT '10',
  `plan_expires_at` timestamp NULL DEFAULT NULL,
  `plan_auto_renew` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (1,'7e4041c3-217a-11f1-8278-aacd190a2fd3','Empresa Demo','demo',NULL,NULL,'America/Bogota','COP',0,'professional',20,50,NULL,0,'2026-03-16 20:55:41','2026-03-19 19:53:42'),(2,'0ae23269-2183-11f1-8278-aacd190a2fd3','ABC Constructores','abc',NULL,NULL,'America/Bogota','COP',1,'professional',50,100,NULL,0,'2026-03-16 21:56:53','2026-03-16 21:56:53');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_2fa_settings`
--

DROP TABLE IF EXISTS `user_2fa_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_2fa_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `backup_codes_count` int DEFAULT '0' COMMENT 'Cantidad de códigos de respaldo disponibles',
  `recovery_codes_last_generated` datetime DEFAULT NULL COMMENT 'Última vez que se generaron códigos',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_user_2fa_settings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_2fa_settings`
--

LOCK TABLES `user_2fa_settings` WRITE;
/*!40000 ALTER TABLE `user_2fa_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_2fa_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Hasheado con bcrypt',
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('super_admin','admin','manager','user') COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT '1',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_login_attempts` int DEFAULT '0',
  `locked_until` timestamp NULL DEFAULT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `require_password_change` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `locale` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT 'es',
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_primary_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#667eea',
  `theme_secondary_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#764ba2',
  `theme_mode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'light',
  `totp_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `webauthn_enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `unique_email_per_tenant` (`tenant_id`,`email`),
  UNIQUE KEY `unique_username_per_tenant` (`tenant_id`,`username`),
  KEY `idx_email` (`email`),
  KEY `idx_tenant_active` (`tenant_id`,`is_active`),
  KEY `idx_role` (`role`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'7e4074f4-217a-11f1-8278-aacd190a2fd3','admin@demo.com','admin','$2y$10$O1CmQSWBwu3t/qTjE0fxf.rZvSaMaeA4qTp8bQKFJCciAjwNrYpVG','Super','Admin','0984876525','super_admin',1,'2026-03-16 20:55:41','2026-03-19 20:49:46','172.19.0.1',0,NULL,NULL,0,'2026-03-16 20:55:41','2026-03-19 21:11:25','en','America/New_York',NULL,'#667eea','#764ba2','dark','E645NAZX236ZIPH5',1,0),(2,2,'11fbf7f3-2183-11f1-8278-aacd190a2fd3','admin@abc.com','admin@abc.com','$2y$13$8K1p/H9OujiUdXnEjI0K.OLm7.3VaQ8KqJnL0BVQZ7yfhg.YJfF0S','Administrador','ABC',NULL,'admin',1,NULL,NULL,NULL,0,NULL,NULL,0,'2026-03-16 21:57:05','2026-03-16 21:57:05','es','America/Guayaquil',NULL,'#667eea','#764ba2','light',NULL,0,0),(3,2,'11fbfb53-2183-11f1-8278-aacd190a2fd3','user@abc.com','user@abc.com','$2y$13$8K1p/H9OujiUdXnEjI0K.OLm7.3VaQ8KqJnL0BVQZ7yfhg.YJfF0S','Usuario','ABC',NULL,'user',1,NULL,NULL,NULL,0,NULL,NULL,0,'2026-03-16 21:57:05','2026-03-16 21:57:05','es','America/Guayaquil',NULL,'#667eea','#764ba2','light',NULL,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_active_projects_per_tenant`
--

DROP TABLE IF EXISTS `v_active_projects_per_tenant`;
/*!50001 DROP VIEW IF EXISTS `v_active_projects_per_tenant`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_active_projects_per_tenant` AS SELECT 
 1 AS `tenant_id`,
 1 AS `tenant_name`,
 1 AS `active_projects`,
 1 AS `max_projects`,
 1 AS `usage_percent`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_active_users_per_tenant`
--

DROP TABLE IF EXISTS `v_active_users_per_tenant`;
/*!50001 DROP VIEW IF EXISTS `v_active_users_per_tenant`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_active_users_per_tenant` AS SELECT 
 1 AS `tenant_id`,
 1 AS `tenant_name`,
 1 AS `active_users`,
 1 AS `max_users`,
 1 AS `usage_percent`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_active_projects_per_tenant`
--

/*!50001 DROP VIEW IF EXISTS `v_active_projects_per_tenant`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_active_projects_per_tenant` AS select `t`.`id` AS `tenant_id`,`t`.`name` AS `tenant_name`,count(`p`.`id`) AS `active_projects`,`t`.`max_projects` AS `max_projects`,((count(`p`.`id`) / `t`.`max_projects`) * 100) AS `usage_percent` from (`tenants` `t` left join `proyectos` `p` on(((`t`.`id` = `p`.`tenant_id`) and (`p`.`status` = 'active')))) where (`t`.`is_active` = true) group by `t`.`id`,`t`.`name`,`t`.`max_projects` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_active_users_per_tenant`
--

/*!50001 DROP VIEW IF EXISTS `v_active_users_per_tenant`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_active_users_per_tenant` AS select `t`.`id` AS `tenant_id`,`t`.`name` AS `tenant_name`,count(`u`.`id`) AS `active_users`,`t`.`max_users` AS `max_users`,((count(`u`.`id`) / `t`.`max_users`) * 100) AS `usage_percent` from (`tenants` `t` left join `users` `u` on(((`t`.`id` = `u`.`tenant_id`) and (`u`.`is_active` = true)))) where (`t`.`is_active` = true) group by `t`.`id`,`t`.`name`,`t`.`max_users` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-19 16:44:29
